import os
import requests

BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
CHANNEL_ID = os.environ["TELEGRAM_CHANNEL_ID"]

url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
r = requests.post(url, json={"chat_id": CHANNEL_ID, "text": "🤖 Deal Bot is running! This is a test message."}, timeout=30)
r.raise_for_status()
print("Message sent successfully")
