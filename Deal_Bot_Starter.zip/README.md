# Deal Bot Starter

Starter structure for a Telegram deals bot.

Important: never put your Telegram bot token, API keys, passwords, or other secrets in this repository. Add secrets through GitHub Actions Secrets.

This starter contains a Telegram posting test and a scheduled GitHub Actions workflow. Store-specific deal APIs/affiliate feeds must be added separately and used according to each service's terms.
